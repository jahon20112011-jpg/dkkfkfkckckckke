# IDROK AI — APK yig‘ish yo‘riqnomasi

Think. Create. Build.

Loyiha ikki qismdan iborat:
- `www/`, `package.json`, `.github/` — Android ilova (Capacitor). APK ni GitHub o‘zi bulutda yig‘adi.
- `server/` — AI serveri. AI kaliti faqat shu yerda saqlanadi, ilova ichida bo‘lmaydi.

## 1-qadam. Bepul AI kalit
1. https://aistudio.google.com saytiga Google akkaunt bilan kiring.
2. "Get API key" orqali kalit oling va nusxalab qo‘ying.
(Bepul tarif shartlari o‘zgarib turadi, saytda tekshiring.)

## 2-qadam. Serverni joylash (Render misolida)
1. GitHub'da yangi repo oching (masalan, `idrok-ai`) va shu ZIP ichidagi hamma narsani yuklang.
2. https://render.com ga GitHub orqali kiring → New → Web Service → shu repoyi tanlang.
3. Sozlamalar: Root Directory = `server`, Build Command = `npm install`, Start Command = `node index.js`.
4. Environment bo‘limida `GEMINI_API_KEY` = sizning kalitingiz. Kerak bo‘lsa `GEMINI_MODEL` ni ham qo‘ying (standart: gemini-2.5-flash).
5. Deploy tugagach, manzilni oling (masalan, https://idrok-ai.onrender.com). Brauzerda ochsangiz "IDROK AI serveri ishlayapti" chiqishi kerak.
Bepul tarifda server uzoq ishlatilmasa uxlab qoladi, birinchi javob sekin kelishi mumkin.

## 3-qadam. Server manzilini ulash
`www/config.js` faylida `window.IDROK_API = 'https://idrok-ai.onrender.com';` deb yozing.
(Yoki APK ni o‘rnatgach, Sozlama → Server manzili maydoniga kiriting.)

## 4-qadam. APK yig‘ish
1. Repoda **Actions** bo‘limini oching → **Build APK** → **Run workflow**.
2. 5–10 daqiqadan keyin ishga tushish sahifasining pastida **Artifacts → idrok-ai-apk** paydo bo‘ladi. Yuklab oling va ZIP ichidan `app-debug.apk` ni chiqaring.
3. Telefonda APK ni oching va "noma’lum manbadan o‘rnatish"ga ruxsat bering.

Muhim: `.github` papkasi (yashirin) repoga albatta yuklansin, aks holda Actions ishlamaydi. Papkalarni yuklash kompyuterda qulayroq. Telefonda GitHub'da "Add file → Create new file" orqali fayl nomiga `.github/workflows/android.yml` deb yozsangiz papkalar o‘zi yaratiladi.

## Eslatmalar
- Bu `debug` APK: shaxsiy foydalanish va sinash uchun. Play Market uchun imzolangan `release` build kerak.
- Ovozdan matn Android WebView'da har doim ishlamaydi. Ishlamasa klaviaturadagi 🎤 dan foydalaning.
- Server ochiq manzil, shuning uchun unda kuniga/daqiqaga cheklov bor (index.js ichida). Manzilni begonalarga bermang.
- Yangi imkoniyat (boshqa AI model, qidiruv) qo‘shish uchun faqat `server/index.js` o‘zgaradi.
